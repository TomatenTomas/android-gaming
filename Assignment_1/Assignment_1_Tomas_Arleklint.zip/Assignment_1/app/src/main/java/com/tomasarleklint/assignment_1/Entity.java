package com.tomasarleklint.assignment_1;

import android.graphics.Canvas;
import android.graphics.Paint;

// Code taken in its entirety from https://studentportalen.uu.se/portal/portal/uusp/student/webpage?uusp.portalpage=true&toolMode=studentUse&entityId=194173&toolAttachmentId=715148

public abstract class Entity {
    static Game _game = null; //shared ref, managed by the Game-class!
    protected float _x = 0;
    protected float _y = 0;
    protected float _width = 0;
    protected float _height = 0;
    protected float _velX = 0;
    protected float _velY = 0;

    void update() {}
    void render(final Canvas canvas, final Paint paint) {}
    void onCollision(final Entity that) {}
    void destroy() {}
    void respawn(){}

    float left() {
        return _x;
    }
    float right() {
        return _x + _width;
    }
    float top() {
        return _y;
    }
    float bottom() {
        return _y + _height;
    }
    float centerX() {
        return _x + (_width * 0.5f);
    }
    float centerY() {
        return _y + (_height * 0.5f);
    }

    void setLeft(final float leftEdgePosition) {
        _x = leftEdgePosition;
    }
    void setRight(final float rightEdgePosition) {
        _x = rightEdgePosition - _width;
    }
    void setTop(final float topEdgePosition) {
        _y = topEdgePosition;
    }
    void setBottom(final float bottomEdgePosition) {
        _y = bottomEdgePosition - _height;
    }
    void setCenter(final float x, final float y) {
        _x = x - (_width * 0.5f);
        _y = y - (_height * 0.5f);
    }

    boolean isColliding(final Entity that) {
        if (this == that) {
            throw new AssertionError("isColliding: You shouldn't test Entities against themselves!");
        }
        return Entity.isAABBOverlapping(this, that);
    }

    //Some good reading on bounding-box intersection tests:
    //https://gamedev.stackexchange.com/questions/586/what-is-the-fastest-way-to-work-out-2d-bounding-box-intersection
    static boolean isAABBOverlapping(final Entity a, final Entity b) {
        return !(a.right() <= b.left()
                || b.right() <= a.left()
                || a.bottom() <= b.top()
                || b.bottom() <= a.top());
    }
}