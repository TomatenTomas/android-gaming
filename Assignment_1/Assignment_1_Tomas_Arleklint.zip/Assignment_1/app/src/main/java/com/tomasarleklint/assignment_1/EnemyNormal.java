package com.tomasarleklint.assignment_1;

public class EnemyNormal extends BitmapEntity{
    EnemyNormal(){
        super();
        respawn();

        int resID = R.drawable.tm_3;
        switch(_game._rng.nextInt(Config.ENEMY_BITMAP_COUNT)) {
            case 0:
                resID = R.drawable.tm_3;
                break;
            case 1:
                resID = R.drawable.tm_4;
                break;
            case 2:
                resID = R.drawable.tm_6;
                break;
            case 3:
                resID = R.drawable.tm_7;
                break;
        }
        loadBitmap(resID, Config.ENEMY_HEIGHT, true);
    }

    @Override
    void update() {
        _velX = -_game._playerSpeed;
        _x += _velX;
        if (right() < 0){
            respawn();
        }
    }

    @Override
    void onCollision(Entity that){
        respawn();
    }
}
