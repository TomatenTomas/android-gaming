package com.tomasarleklint.assignment_1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button easyButton = findViewById(R.id.easyButton);
        easyButton.setOnClickListener(this);
        final Button mediumButton = findViewById(R.id.mediumButton);
        mediumButton.setOnClickListener(this);
        final Button hardButton = findViewById(R.id.hardButton);
        hardButton.setOnClickListener(this);

        final TextView highScore = findViewById(R.id.highscore_text);
        SharedPreferences prefs = getSharedPreferences(getResources().getString(R.string.PREFS), Context.MODE_PRIVATE);
        int longestDistance = prefs.getInt(getResources().getString(R.string.LONGEST_DIST), 0);
        highScore.setText(getResources().getString(R.string.highScoreText, longestDistance));
    }

    @Override
    public void onClick(View v) {
        float difficulty = 0;
        switch (v.getId()) {
            case R.id.easyButton:
                difficulty = Config.DIFF_EASY;
                break;
            case R.id.mediumButton:
                difficulty = Config.DIFF_MEDIUM;
                break;
            case R.id.hardButton:
                difficulty = Config.DIFF_HARD;
                break;
            default:
                break;
        }


        final Intent i = new Intent(this, GameActivity.class);
        i.putExtra(getResources().getString(R.string.DIFFICULTY), difficulty);
        startActivity(i);
        finish();
    }
}