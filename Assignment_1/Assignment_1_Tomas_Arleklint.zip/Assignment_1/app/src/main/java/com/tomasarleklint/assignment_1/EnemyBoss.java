package com.tomasarleklint.assignment_1;


public class EnemyBoss extends BitmapEntity{
    private float _randomPhaseShift = 0;
    private static float _x_sine = 0;

    EnemyBoss(){
        super();
        respawnBoss();

        int resID = R.drawable.tm_1;
        loadBitmap(resID, Config.BOSS_HEIGHT, true);
    }

    void update() {
        float radiansPS = 0;
        float sineY = 0;

        _velX = - _game._playerSpeed;
        _x += _velX;
        _x_sine -= 10f;
        radiansPS = Math.abs(_x_sine-Config.STAGE_WIDTH)/Config.STAGE_WIDTH;
        sineY = (float) Math.sin(Math.PI * radiansPS + _randomPhaseShift);
        _y = Config.BOSS_SINE_AMPLITUDE * sineY + Config.BOSS_SINE_AMPLITUDE;

        if (right() < 0){
            respawnBoss();
            _game._drawBoss = false;
        }
    }

    private void respawnBoss(){
        respawn();
        _x_sine = Config.STAGE_WIDTH;
        _randomPhaseShift = (float) (_game._rng.nextFloat()*Math.PI);
    }

    @Override
    void onCollision(Entity that){
        respawnBoss();
        _game._drawBoss = false;
    }
}
