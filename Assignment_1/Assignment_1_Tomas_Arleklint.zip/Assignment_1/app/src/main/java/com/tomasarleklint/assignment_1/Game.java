package com.tomasarleklint.assignment_1;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.media.SoundPool;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Random;


public class Game extends SurfaceView implements Runnable {
    private Thread _gameThread = null;
    private volatile boolean _isRunning = false;
    private SurfaceHolder _holder = null;
    public final Paint _paint = new Paint();
    private Canvas _canvas = null;

    private final ArrayList<Entity> _entitiesBackground = new ArrayList<>();
    private final ArrayList<Entity> _entitiesEnemies = new ArrayList<>();
    private final ArrayList<Entity> _entitiesBosses = new ArrayList<>();

    public Player _player = null;
    final Random _rng = new Random();
    private Jukebox _jukebox = null;
    private SharedPreferences _prefs = null;
    private SharedPreferences.Editor _editor = null;

    volatile boolean _isBoosting = false;
    float _playerSpeed = 0f;
    int _distanceTravelled = 0;
    private int _maxDistanceTravelled = 0;
    boolean _gameOver = false;
    boolean _drawBoss = false;
    private int _bossesSpawned = 0;
    boolean _invulnerable = false;
    boolean _invulnframe = false;
    private boolean _start_sound_ready = false;
    private boolean _boost_sound_ready = false;

    public Game(Context context, final float difficulty) {
        super(context);
        Entity._game = this;
        HUD._game = this;
        _holder = getHolder();
        _holder.setFixedSize(Config.STAGE_WIDTH, Config.STAGE_HEIGHT);
        _jukebox = new Jukebox(context);

        _prefs = context.getSharedPreferences(getResources()
                .getString(R.string.PREFS), Context.MODE_PRIVATE);
        _editor = _prefs.edit();
        _editor.apply();

        for (int i = 0; i < Config.STAR_COUNT; i++) {
            _entitiesBackground.add(new Star());
        }
        for (int i = 0; i < Config.ENEMY_COUNT*difficulty; i++) {
            _entitiesEnemies.add(new EnemyNormal());
        }
        for (int i = 0; i < Config.BOSS_COUNT; i++) {
            _entitiesBosses.add(new EnemyBoss());
        }
        _player = new Player();

        _jukebox._soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener(){
            @Override
            public void onLoadComplete(SoundPool soundPool, int sampleID, int status) {
                if(sampleID == Config.GAME_START){
                    _start_sound_ready = true;
                } else if (sampleID == Config.BOOST){
                    _boost_sound_ready = true;
                }
                if(_start_sound_ready && _boost_sound_ready){
                    _jukebox.play(Config.GAME_START);
                }
            }
        });
        restart();
    }

    private void restart(){

        for (Entity e : _entitiesBackground) {
            e.respawn();
        }
        for (Entity e : _entitiesEnemies) {
            e.respawn();
        }
        _player.respawn();
        _distanceTravelled = 0;
        _bossesSpawned = 0;
        _maxDistanceTravelled = _prefs.getInt(getResources().getString(R.string.LONGEST_DIST), 0);
        _gameOver = false;
        _drawBoss = false;
        _invulnerable = false;
        _invulnframe = false;
        _jukebox.play(Config.GAME_START);
    }

    @Override
    public void run() {
        while (_isRunning) {
            update();
            render();
        }
    }

    private void update() {
        if (_gameOver){
            return;
        }

        if (!_drawBoss){
            if(_distanceTravelled > Config.BOSS_INTERVAL*(_bossesSpawned+1)){
                _drawBoss = true;
                _bossesSpawned++;
            }
        }

        _player.update();
        for (Entity e : _entitiesBackground) {
            e.update();
        }
        for (Entity e : _entitiesEnemies) {
            e.update();
        }
        if (_drawBoss){
            for (Entity e : _entitiesBosses) {
                e.update();
            }
        }

        _distanceTravelled += _playerSpeed;
        checkCollisions(_entitiesEnemies);
        if(_drawBoss){
            checkCollisions(_entitiesBosses);
        }
        checkGameOver();
    }

    private void checkGameOver() {
        if(_player._health < 1) {
            _gameOver = true;
            if(_distanceTravelled > _maxDistanceTravelled){
                _maxDistanceTravelled = _distanceTravelled;
                _editor.putInt(getResources().getString(R.string.LONGEST_DIST), _maxDistanceTravelled);
                _editor.apply();
            }
            _jukebox.play(Config.GAME_OVER);
        }
    }

    private void checkCollisions(final ArrayList<Entity> entityList){
        Entity temp = null;
        for (int i = 0; i < entityList.size(); i++) {
            temp = entityList.get(i);
            if(_player.isColliding(temp)) {
                _player.onCollision(temp);
                temp.onCollision(_player);
                _invulnerable = true;
                if(_player._health > 0){
                    _jukebox.play(Config.CRASH);
                }
            }
        }
    }

    private void render() {
        if (!lockCanvas()) {
            return;
        }

        _canvas.drawColor(Color.BLACK);

        for (Entity e : _entitiesBackground) {
            e.render(_canvas, _paint);
        }
        for (Entity e : _entitiesEnemies) {
            e.render(_canvas, _paint);
        }
        if (_drawBoss){
            for (Entity e : _entitiesBosses) {
                e.render(_canvas, _paint);
            }
        }

        int saturation = (_invulnframe) ? 0 : 1;
        setGrayscale(saturation);
        _player.render(_canvas, _paint);
        setGrayscale(1);

        HUD.renderHUD(_canvas, _paint);
        _holder.unlockCanvasAndPost(_canvas);
    }

    private void setGrayscale(final int saturation){
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(saturation);
        ColorMatrixColorFilter filter = new ColorMatrixColorFilter(cm);
        _paint.setColorFilter(filter);
    }

    private boolean lockCanvas() {
        if (!_holder.getSurface().isValid()) {
            return false;
        }
        _canvas = _holder.lockCanvas();
        return (_canvas != null);
    }

    protected void onResume() {
        Log.d(getResources().getString(R.string.TAG_GAME), "onResume");
        _isRunning = true;
        _gameThread = new Thread(this);
        _gameThread.start();
    }

    protected void onPause() {
        Log.d(getResources().getString(R.string.TAG_GAME), "onPause");
        _isRunning = false;
        try {
            _gameThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
            Log.d(getResources().getString(R.string.TAG_GAME), Log.getStackTraceString(e.getCause()));
        }
    }

    protected void onDestroy() {
        Log.d(getResources().getString(R.string.TAG_GAME), "onDestroy");
        _gameThread = null;
        for (Entity e : _entitiesBackground) {
            e.destroy();
        }
        for(Entity e : _entitiesEnemies) {
            e.destroy();
        }
        for(Entity e : _entitiesBosses) {
            e.destroy();
        }
        _player.destroy();
        _jukebox.destroy();
        Entity._game = null;
    }

    @Override
    public boolean onTouchEvent(final MotionEvent event) {
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_UP: //finger lifted
                _isBoosting = false;
                _jukebox.stop(Config.BOOST);
                if(_gameOver){
                    restart();
                }
                break;
            case MotionEvent.ACTION_DOWN:   //finger pressed
                _isBoosting = true;
                _jukebox.play(Config.BOOST);
                break;
        }
        return true;
    }
}
