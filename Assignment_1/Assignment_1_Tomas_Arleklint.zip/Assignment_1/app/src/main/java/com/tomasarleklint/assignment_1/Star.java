package com.tomasarleklint.assignment_1;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Star extends Entity{
    private float _radius = 0;
    private int _color = 0;

    Star(){
        _x = _game._rng.nextInt(Config.STAGE_WIDTH);
        _y = _game._rng.nextInt(Config.STAGE_HEIGHT);
        _radius = _game._rng.nextInt(Config.STAR_UPPER_BOUND) + Config.STAR_LOWER_BOUND; //2-8
        _width = _radius*2;
        _height = _radius*2;
        _velX = 0;
        _color = getStarColor();
    }

    @Override
    void update() {
        _velX = -_game._playerSpeed/Config.STAR_PLAYER_SPEED_RATIO;
        _x += _velX;
        _x = Utils.wrap(_x, 0, Config.STAGE_WIDTH + _width);
    }

    @Override
    void render(Canvas canvas, Paint paint) {
        paint.setColor(_color);
        canvas.drawCircle(_x+_radius, _y+_radius, _radius, paint);
    }

    private int getStarColor(){
        int opacity = Config.STAR_OPACITY;
        int blue = randomizeStarColor();
        int green = randomizeStarColor() << 8;
        int red = randomizeStarColor() << 16;
        return opacity + red + green + blue;
    }

    private int randomizeStarColor(){
        return _game._rng.nextInt(Config.STAR_COLOR_UPPER_BOUND) + Config.STAR_COLOR_LOWER_BOUND;
    }
}
