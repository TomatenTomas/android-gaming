package com.tomasarleklint.assignment_1;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class HUD {
    static Game _game = null;

    public HUD(){
    }

    public static void renderHUD(final Canvas canvas, final Paint paint){
        final float textSize = 48f;
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTextSize(textSize);
        if(!_game._gameOver) {
            canvas.drawText(_game.getResources().getString(R.string.HEALTH, _game._player._health), 10, textSize, _game._paint);
            canvas.drawText(_game.getResources().getString(R.string.DISTANCE, _game._distanceTravelled), 10, textSize*2, _game._paint);
        }else{
            final float centerY = (float) Config.STAGE_HEIGHT/2;
            canvas.drawText(_game.getResources().getString(R.string.GAME_OVER), (float)Config.STAGE_WIDTH/2, centerY, _game._paint);
            canvas.drawText(_game.getResources().getString(R.string.PRESS_RESTART), (float)Config.STAGE_WIDTH/2, centerY + textSize, _game._paint);
        }
    }
}
