package com.tomasarleklint.assignment_1;

public class Config {
    public static final float DIFF_EASY = 0.5f;
    public static final float DIFF_MEDIUM = 1f;
    public static final float DIFF_HARD = 1.5f;

    public static final int STAGE_WIDTH = 1280;
    public static final int STAGE_HEIGHT = 720;
    public static final int STAR_COUNT = 40;
    public static final int ENEMY_COUNT = 8;

    public static final int ENEMY_HEIGHT = 50;
    public static final int ENEMY_SPAWN_OFFSET = STAGE_WIDTH;
    public static final int ENEMY_BITMAP_COUNT = 4;

    public static final int BOSS_HEIGHT = 70;
    public static final int BOSS_INTERVAL = 5000;
    public static final int BOSS_COUNT = 1;
    public static final float BOSS_SINE_AMPLITUDE = (float) (Config.STAGE_HEIGHT - Config.BOSS_HEIGHT) / 2;

    public static final int STAR_OPACITY = 0xFF000000;
    public static final int STAR_COLOR_LOWER_BOUND = 0x30;
    public static final int STAR_COLOR_UPPER_BOUND = 0xCF;
    public static final int STAR_UPPER_BOUND = 4;
    public static final int STAR_LOWER_BOUND = 2;
    public static final int STAR_PLAYER_SPEED_RATIO = 10;

    public final static int TARGET_HEIGHT = 65;
    public final static int STARTING_POSITION = 40;
    public final static int STARTING_HEALTH = 3;

    public static final float ACC = 1.08f;
    public static final float MIN_VEL = 1f;
    public static final float MAX_VEL = 15f;
    public static final float GRAVITY = 1.03f;
    public static final float LIFT = -(GRAVITY*2);
    public static final float DRAG = 0.98f;
    public static final int INVULN_DURATION = 1000;
    public static final int INVULN_TICK = INVULN_DURATION/8;

    public static final int MAX_STREAMS = 3;
    public static int CRASH = 0;
    public static int GAME_OVER = 0;
    public static int GAME_START = 0;
    public static int BOOST = 0;
    public static final float LEFT_VOLUME = 1f;
    public static final float RIGHT_VOLUME = 1f;
    public static final int PRIORITY = 1;
    public static final int LOOP_ONCE = 0;
    public static final int LOOP_ALWAYS = -1;
    public static final float RATE = 1.0f;

}
