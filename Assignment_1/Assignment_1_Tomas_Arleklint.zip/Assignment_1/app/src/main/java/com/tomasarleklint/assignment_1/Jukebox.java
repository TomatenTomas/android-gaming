package com.tomasarleklint.assignment_1;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.io.IOException;
import java.util.Hashtable;

public class Jukebox {
    SoundPool _soundPool = null;
    private final Hashtable<Integer, Integer> id_stream_dict = new Hashtable<Integer, Integer>();

    Jukebox(final Context context){
        AudioAttributes attr = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        _soundPool = new SoundPool.Builder()
                .setAudioAttributes(attr)
                .setMaxStreams(Config.MAX_STREAMS)
                .build();

        loadSounds(context);
    }

    private void loadSounds(final Context context){
        try {
            AssetManager assetManager = context.getAssets();
            AssetFileDescriptor descriptor;
            descriptor = assetManager.openFd("crash.wav");
            Config.CRASH =_soundPool.load(descriptor, Config.PRIORITY);
            descriptor = assetManager.openFd("game_over.wav");
            Config.GAME_OVER = _soundPool.load(descriptor, Config.PRIORITY);
            descriptor = assetManager.openFd("game_start.wav");
            Config.GAME_START = _soundPool.load(descriptor, Config.PRIORITY);
            descriptor = assetManager.openFd("boost.wav");
            Config.BOOST = _soundPool.load(descriptor, Config.PRIORITY);
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    void play(final int soundID){
        int loop = Config.LOOP_ONCE;
        int soundStream = 0;
        if (soundID == Config.BOOST){
            loop = Config.LOOP_ALWAYS;
        }
        if (soundID > 0) {
            soundStream = _soundPool.play(soundID, Config.LEFT_VOLUME, Config.RIGHT_VOLUME, Config.PRIORITY, loop, Config.RATE);
            id_stream_dict.put(soundID, soundStream);
        }
    }

    void stop(final int soundID){
        if (soundID > 0){
            try {
                _soundPool.stop(id_stream_dict.get(soundID));
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
        }
    }

    void destroy(){
        _soundPool.release();
        _soundPool = null;
    }

}
