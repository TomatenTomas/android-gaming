package com.tomasarleklint.assignment_1;

import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;

public class Player extends BitmapEntity {
    int _health = Config.STARTING_HEALTH;

    Player(){
        super();
        loadBitmap(R.drawable.player_ship, Config.TARGET_HEIGHT, false);
        respawn();
    }

    @Override
    void respawn(){
        _x = Config.STARTING_POSITION;
        _health = Config.STARTING_HEALTH;
        _velX = 0f;
        _velY = 0f;
    }

    @Override
    void update() {
        _velX *= Config.DRAG;
        _velY += Config.GRAVITY;
        if(_game._isBoosting){
            _velX *= Config.ACC;
            _velY += Config.LIFT;
        }
        _velX = Utils.clamp(_velX, Config.MIN_VEL, Config.MAX_VEL);
        _velY = Utils.clamp(_velY, -Config.MAX_VEL, Config.MAX_VEL);
        _y += _velY;
        _y = Utils.clamp(_y, 0, Config.STAGE_HEIGHT-_height);
        _game._playerSpeed = _velX;
    }

    @Override
    void onCollision(Entity that) {
        if(!_game._invulnerable){
            _health--;
            if(_health > 0){
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        new CountDownTimer(Config.INVULN_DURATION, Config.INVULN_TICK) {
                            @Override
                            public void onTick(long l) {
                                _game._invulnframe = !_game._invulnframe;
                            }

                            @Override
                            public void onFinish() {
                                _game._invulnerable = false;
                                _game._invulnframe = false;
                            }
                        }.start();
                    }
                });
            }
        }
    }
}
