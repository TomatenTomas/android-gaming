package com.tomasarleklint.assignment_3.input;

public class InputManager {
    public float _verticalFactor = 0.0f;
    public float _horizontalFactor = 0.0f;
    public boolean _pressingA = false;
    public boolean _pressingB = false;

    public void onStart() {};
    public void onStop() {};
    public void onPause() {};
    public void onResume() {};
}