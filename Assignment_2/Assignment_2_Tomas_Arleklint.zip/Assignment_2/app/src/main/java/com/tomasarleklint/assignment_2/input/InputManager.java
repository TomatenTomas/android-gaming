package com.tomasarleklint.assignment_2.input;

public class InputManager {
    public float _verticalFactor = 0.0f;
    public float _horizontalFactor = 0.0f;
    public boolean _isJumping = false;

    public void onStart() {}
    public void onStop() {}
    public void onPause() {}
    public void onResume() {}
}